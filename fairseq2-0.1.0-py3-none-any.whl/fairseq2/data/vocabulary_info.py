# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class VocabularyInfo:
    size: int
    """The size of the vocabulary."""

    unk_idx: Optional[int]
    """The index of the symbol that represents an unknown element."""

    bos_idx: Optional[int]
    """The index of the symbol that represents the beginning of a sequence."""

    eos_idx: Optional[int]
    """The index of the symbol that represents the end of a sequence."""

    pad_idx: Optional[int]
    """The index of the symbol that is used to pad a sequence."""
